package ar.org.centro8.curso.java.enums;

public enum EstadoCivil {
    SOLTERO,
    CASADO,
    VIUDO,
    DIVORCIADO
}
