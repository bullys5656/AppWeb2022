
package ar.org.centro8.curso.java.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ar.org.centro8.curso.java.data.services.ArticuloDataService;
import ar.org.centro8.curso.java.entities.Articulo;
import ar.org.centro8.curso.java.enums.Rubro;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("servicios/articulos/v1")
public class ArticuloController {
    @Autowired
    private ArticuloDataService ads;
    
    @GetMapping()
    public String info(){
        return "Servicio articulos Activo";
    }

   
    @PostMapping("/alta")
    public String save(
        @RequestParam("descripcion")    String descripcion,              
        @RequestParam("rubro")          String rubro,    
        @RequestParam("costo")          Double costo,
        @RequestParam("precio")         Double precio,        
        @RequestParam("stock")          Integer stock,
        @RequestParam("stock_minimo")   Integer stock_minimo,                
        @RequestParam("stock_maximo")   Integer stock_maximo
    ){
        try{
            Articulo articulo=new Articulo(
                descripcion,                         
                Rubro.valueOf(rubro),              
                costo,                              
                precio,                             
                stock,                            
                stock_minimo,                       
                stock_maximo                        
            );

            ads.save(articulo);

            return articulo.getId()+"";
        }catch(Exception e){
            return "0";
        }
    }

    @PostMapping(value="/baja")
    public String baja(@RequestParam("id") int id) {
        try{
            ads.remove(id);
            return "true";
        }catch(Exception e){
            return "false";
        }
    }

    @GetMapping(value="/all")
    public List<Articulo>getAll(){
        return ads.getAll();
    }
    

    @GetMapping(value="/byId")
    public Articulo getById(int id){
        return ads.getById(id);
    }

    
    @GetMapping(value="/LikeDescripcion")
    public List<Articulo> getLikeDescripcion(String descripcion){
        return ads.getLikeDescripcion(descripcion);
    }
    
    
    
}
