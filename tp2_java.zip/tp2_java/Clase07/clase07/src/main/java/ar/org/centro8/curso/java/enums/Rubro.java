
package ar.org.centro8.curso.java.enums;


public enum Rubro {
     LACTEOS,
    PANADERIA,
    LIMPIEZA,
    PERSONAL,
    FIAMBRES,
    CARNICERIA,
    BEBIDAS
}
